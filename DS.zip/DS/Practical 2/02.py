import pandas as pd

# Reading the CSV file
df = pd.read_csv('C:/Users/Student/Desktop/RaJ/DS/Practical 2/Student_Marks.csv')

# Printing the first 5 rows of the dataset
print("Our dataset (first 5 rows):")
print(df.head())
