import pandas as pd

# Reading the JSON file
data = pd.read_json('C:/Users/Student/Desktop/RaJ/DS/Practical 2/dataset.json')

# Printing the data
print(data)
